
var app = app || {};

(function(window, app){

	app.func2 = function(){};

})(window, app);
