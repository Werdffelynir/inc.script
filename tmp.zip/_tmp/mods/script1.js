
var app = app || {};

(function(window, app){

	document.addEventListener('DOMContentLoaded', function(e){});

	var page = document.querySelector('#page');
	page.style.color = '#AA1145';
	page.style.width = '800px';
	page.style.margin = '0 auto';
	
	app.func1 = function(){};

})(window, app);
