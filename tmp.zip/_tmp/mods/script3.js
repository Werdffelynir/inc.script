
var app = app || {};

(function(window, app){

	app.func3 = function(){};

})(window, app);
